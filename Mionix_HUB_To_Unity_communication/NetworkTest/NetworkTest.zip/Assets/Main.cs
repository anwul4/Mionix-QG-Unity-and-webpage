﻿using UnityEngine;
using System.Collections;
using WebSocketSharp;
using UnityEngine.UI;
using System;

public class Main : MonoBehaviour {
    private bool connected = false;
    WebSocket ws;
    Color c = new Color(255, 0, 0);

    private void Ws_OnError(object sender, ErrorEventArgs e)
    {
        Debug.Log("Error");
        c = new Color(255, 0, 255);
    }

    private void Ws_OnClose(object sender, CloseEventArgs e)
    {
        Debug.Log("Close");
        c = new Color(255, 255, 0);
    }

    private void Ws_OnMessage(object sender, MessageEventArgs e)
    {
        string data = e.Data.ToString();
        if (data.Contains("gsr"))
        {
            data = data.Remove(0, data.IndexOf("gsr") + 5);
            data = data.Replace("}", "");
            Debug.Log("message: " + data);
            var cc = (int)(255 * Convert.ToDouble(data));
            Debug.Log("color: " + cc);
            if(cc < 50)  c = new Color(255, 0, 255);
            else if (cc < 100) c = new Color(0, 255, 0);
            else if (cc < 200) c = new Color(0, 0, 255);
            else c = new Color(255, 255, 0);
        }
    }

    private void Ws_OnOpen(object sender, System.EventArgs e)
    {
       
        c = new Color(0, 0, 255);
        Debug.Log("Open");
        ws.SendAsync("echo", OnSendComplete);
    }
    private void OnSendComplete(bool success)
    {
        Debug.Log("message Sent:" + success);
    }
    // Use this for initialization
    void Start () {
        
        Debug.Log("Start");

        if (!connected)
        {
            ws = new WebSocket("ws://localhost:7681/","mionix-beta");
            ws.OnOpen += Ws_OnOpen;
            ws.OnMessage += Ws_OnMessage;
            ws.OnClose += Ws_OnClose;
            ws.OnError += Ws_OnError;
            ws.ConnectAsync();
        }
    }
	
	// Update is called once per frame
	void Update () {
        Camera.main.backgroundColor = c;
    }
    void OnApplicationQuit()
    {
        ws.Close();
    }

}
